﻿namespace DataLogger.DashboardViews.eNum
{
    public enum eSelectData
    {
        speed = 0,
        temperature = 1,
    }

}
