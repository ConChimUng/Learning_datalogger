﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataLogger.DashboardViews
{
    public partial class UserControlProgessBar : UserControl
    {
        private eProgessBarType _eProgessBarType = eProgessBarType.Speed;
        public enum eProgessBarType
        {
            Speed,
            Temperature
        }

        public void SetProgessBarType(eProgessBarType eProgessBarType)
        {
            this._eProgessBarType =eProgessBarType;
            switch (eProgessBarType)
            {
                case eProgessBarType.Speed:
                    cprBar1.SuperscriptText = "spr";
                    break;
                case eProgessBarType.Temperature:
                    cprBar1.SuperscriptText = "oC";
                    break;
                default:break;
            }
        }


        public UserControlProgessBar()
        {
            InitializeComponent();
        }
         
        public void ChangeValue(int data)
        {
            cprBar1.Text = data.ToString();
            cprBar1.Value = data;
        }

    }
}
