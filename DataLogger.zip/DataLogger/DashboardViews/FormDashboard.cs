﻿using DataLogger.DashboardViews.eNum;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataLogger.DashboardViews
{
    public partial class FormDashboard : Form
    {
        #region 
        public static FormDashboard _Instance = null;
        public static FormDashboard Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new FormDashboard();
                }
                return _Instance;
            }
        }
        #endregion
        public FormDashboard()
        {
            InitializeComponent();
            //this.Load += userControlProgessBar1_Load;
            userControlProgessBar1.SetProgessBarType(UserControlProgessBar.eProgessBarType.Speed);
            userControlProgessBar2.SetProgessBarType(UserControlProgessBar.eProgessBarType.Temperature);
        }

        public int _temperature;
        public int _speed;
       

        public void tmr1_Tick(object sender, EventArgs e)
        {
            Random rd = new Random();
            _speed = rd.Next(70, 100);
            _temperature = rd.Next(20,40);
            tmr1.Start();
            UserControlProgessBar userControlProgessBar = new UserControlProgessBar();
           

            userControlProgessBar1.ChangeValue(_speed);

            userControlProgessBar2.ChangeValue(_temperature);


        }

        private void FormDashboard_Load_1(object sender, EventArgs e)
        {
            tmr1.Start();
        }
    }
}
