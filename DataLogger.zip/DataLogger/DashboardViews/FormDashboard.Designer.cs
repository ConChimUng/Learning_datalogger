﻿namespace DataLogger.DashboardViews
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmr1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.userControlProgessBar2 = new DataLogger.DashboardViews.UserControlProgessBar();
            this.userControlProgessBar1 = new DataLogger.DashboardViews.UserControlProgessBar();
            this.userControlDisplayHeader1 = new DataLogger.DashboardViews.UserControlDisplayHeader();
            this.SuspendLayout();
            // 
            // tmr1
            // 
            this.tmr1.Interval = 500;
            this.tmr1.Tick += new System.EventHandler(this.tmr1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(553, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // userControlProgessBar2
            // 
            this.userControlProgessBar2.BackColor = System.Drawing.Color.Navy;
            this.userControlProgessBar2.Location = new System.Drawing.Point(21, 257);
            this.userControlProgessBar2.Name = "userControlProgessBar2";
            this.userControlProgessBar2.Size = new System.Drawing.Size(297, 188);
            this.userControlProgessBar2.TabIndex = 1;
            // 
            // userControlProgessBar1
            // 
            this.userControlProgessBar1.BackColor = System.Drawing.Color.Navy;
            this.userControlProgessBar1.Location = new System.Drawing.Point(376, 22);
            this.userControlProgessBar1.Name = "userControlProgessBar1";
            this.userControlProgessBar1.Size = new System.Drawing.Size(297, 188);
            this.userControlProgessBar1.TabIndex = 1;
            // 
            // userControlDisplayHeader1
            // 
            this.userControlDisplayHeader1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.userControlDisplayHeader1.Location = new System.Drawing.Point(21, 22);
            this.userControlDisplayHeader1.Name = "userControlDisplayHeader1";
            this.userControlDisplayHeader1.Size = new System.Drawing.Size(297, 188);
            this.userControlDisplayHeader1.TabIndex = 0;
            // 
            // FormDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1205, 605);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.userControlProgessBar2);
            this.Controls.Add(this.userControlProgessBar1);
            this.Controls.Add(this.userControlDisplayHeader1);
            this.Name = "FormDashboard";
            this.Text = "FormDashboard";
            this.Load += new System.EventHandler(this.FormDashboard_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private UserControlDisplayHeader userControlDisplayHeader1;
        private UserControlProgessBar userControlProgessBar1;
        private UserControlProgessBar userControlProgessBar2;
        private System.Windows.Forms.Timer tmr1;
        private System.Windows.Forms.Label label1;
    }
}